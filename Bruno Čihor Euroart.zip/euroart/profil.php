<?php 
session_start();
if (!isset($_SESSION['kod'])) 
{
  	header('location: index.php');
}
if (isset($_GET['logout']))
{
	session_destroy();
	unset($_SESSION['kod']);
	header("location: index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="keywords" content="">
		<title>Zahtjevi za server</title>
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<script src="js/jquery-2.1.4.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
	</head>
	<body>
		<?php include 'connection.php';  ?>
		<nav class="navbar navbar-default">
			<div class="container-fluid">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="#">Zahtjevi za server</a>
				</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
						<li><a href="#">Prijava</a></li>
						<li class="active"><a href="lista.php">Lista prijava</a></li>
						<li class="active"><a href="lista.php?logout='1'">Odjava</a></li>
					</ul>
				</div>
			</div>
		</nav>
		<div class="container">
			<h1>Profil</h1>
			<?php 
				$kod = $_GET['kod'];
				$query = "SELECT * FROM prijava WHERE kod = '".$kod."'";
				$result = mysqli_query($conn,$query);
				while($row = mysqli_fetch_array($result)) { 
			echo '<form action="" method="">
				<div class="form-group">
					<label for="email">Email adresa</label>
					<input type="email" class="form-control" id="email" name="email" value="'.$row['email'].'" readonly>
				</div>
				<div class="form-group">
					<label for="php">Vrijeme prijave</label>
					<input type="text" class="form-control" id="time" name="time" value="'.$row['vrijeme'].'" readonly>
				</div>
				<div class="form-group">
					<label for="php">Kod</label>
					<input type="text" class="form-control" id="code" name="code" value="'.$row['kod'].'" readonly>
				</div>
				<div class="form-group">
					<label for="php">PHP verzija</label>
					<input type="text" class="form-control" id="php" name="php" value="'.$row['php'].'" readonly>
				</div>
				<div class="form-group">
					<label for="mysql">Opis prijave</label>
					<textarea class="form-control" rows="3" name="opis" maxlength="200" placeholder="Upisite opis vaše prijave!" readonly>'.$row['opis'].'</textarea>
				</div>
			</form>';
		} ?>
		</div>
</body>
</html>